export const members = [
  {
    member_id: 1,
    user_id: 101,
    first_name: 'Ayse',
    last_name: 'Yilmaz',
    phone_number: '+905551112233',
    date_of_birth: '1995-03-14',
    membership_date: '2022-09-01',
    status: 'active',
    current_loans: 2
  },
  {
    member_id: 2,
    user_id: 102,
    first_name: 'Mehmet',
    last_name: 'Demir',
    phone_number: '+905553334455',
    date_of_birth: '1991-11-02',
    membership_date: '2023-01-15',
    status: 'delinquent',
    current_loans: 1
  },
  {
    member_id: 3,
    user_id: 103,
    first_name: 'Selin',
    last_name: 'Kaynar',
    phone_number: '+905558887766',
    date_of_birth: '2000-05-21',
    membership_date: '2024-04-03',
    status: 'active',
    current_loans: 0
  }
]
