import { useState } from 'react'

const initialValues = { email: '', password: '' }

function validate(values) {
  const errors = {}
  if (!values.email.trim()) errors.email = 'Email is required'
  else if (!/^[\w.-]+@([\w-]+\.)+[\w-]{2,}$/.test(values.email)) errors.email = 'Enter a valid email'
  if (!values.password) errors.password = 'Password is required'
  else if (values.password.length < 8) errors.password = 'At least 8 characters required'
  return errors
}

function LoginForm() {
  const [values, setValues] = useState(initialValues)
  const [errors, setErrors] = useState({})
  const [message, setMessage] = useState('')

  const handleChange = event => {
    setValues({ ...values, [event.target.name]: event.target.value })
    setErrors({ ...errors, [event.target.name]: '' })
    setMessage('')
  }

  const handleSubmit = event => {
    event.preventDefault()
    const nextErrors = validate(values)
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length === 0) {
      setMessage('Login request sent')
    }
  }

  return (
    <form className="card form" onSubmit={handleSubmit}>
      <h2>Sign In</h2>
      <label>
        Email
        <input name="email" type="email" value={values.email} onChange={handleChange} placeholder="you@example.com" />
        {errors.email && <span className="form__error">{errors.email}</span>}
      </label>
      <label>
        Password
        <input name="password" type="password" value={values.password} onChange={handleChange} placeholder="Minimum 8 characters" />
        {errors.password && <span className="form__error">{errors.password}</span>}
      </label>
      <button type="submit">Login</button>
      {message && <p className="form__success">{message}</p>}
    </form>
  )
}

export default LoginForm
