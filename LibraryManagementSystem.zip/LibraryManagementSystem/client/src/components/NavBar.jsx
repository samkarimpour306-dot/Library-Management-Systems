import { NavLink } from 'react-router-dom'

const links = [
  { to: '/', label: 'Dashboard' },
  { to: '/members', label: 'Members' },
  { to: '/login', label: 'Login' },
  { to: '/register', label: 'Register' }
]

function NavBar() {
  return (
    <header className="nav">
      <div className="nav__brand">LibraryMS</div>
      <nav className="nav__links">
        {links.map(link => (
          <NavLink
            key={link.to}
            to={link.to}
            className={({ isActive }) => (isActive ? 'nav__link nav__link--active' : 'nav__link')}
          >
            {link.label}
          </NavLink>
        ))}
      </nav>
    </header>
  )
}

export default NavBar
