import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { members } from '../data/members'

function MemberList() {
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState('all')

  const filteredMembers = useMemo(() => {
    return members.filter(member => {
      const matchesQuery =
        member.first_name.toLowerCase().includes(query.toLowerCase()) ||
        member.last_name.toLowerCase().includes(query.toLowerCase()) ||
        `${member.first_name} ${member.last_name}`.toLowerCase().includes(query.toLowerCase())
      const matchesFilter = filter === 'all' ? true : member.status === filter
      return matchesQuery && matchesFilter
    })
  }, [query, filter])

  return (
    <section className="card">
      <div className="list__controls">
        <input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search by name" />
        <select value={filter} onChange={event => setFilter(event.target.value)}>
          <option value="all">All Statuses</option>
          <option value="active">Active</option>
          <option value="delinquent">Delinquent</option>
        </select>
      </div>
      <ul className="list">
        {filteredMembers.map(member => (
          <li key={member.member_id} className="list__item">
            <div>
              <p className="list__title">
                {member.first_name} {member.last_name}
              </p>
              <p>{member.phone_number}</p>
            </div>
            <div className={`status status--${member.status}`}>{member.status}</div>
            <Link to={`/members/${member.member_id}`} className="link">
              View
            </Link>
          </li>
        ))}
        {filteredMembers.length === 0 && <li className="list__empty">No members found</li>}
      </ul>
    </section>
  )
}

export default MemberList
