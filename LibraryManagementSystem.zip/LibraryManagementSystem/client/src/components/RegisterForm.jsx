import { useState } from 'react'

const initialValues = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  password: '',
  confirmPassword: '',
  role: 'member'
}

function validate(values) {
  const errors = {}
  if (!values.firstName.trim()) errors.firstName = 'First name required'
  if (!values.lastName.trim()) errors.lastName = 'Last name required'
  if (!values.email.trim()) errors.email = 'Email required'
  else if (!/^[\w.-]+@([\w-]+\.)+[\w-]{2,}$/.test(values.email)) errors.email = 'Invalid email'
  if (!values.phone.trim()) errors.phone = 'Phone required'
  else if (!/^\+?[0-9]{7,15}$/.test(values.phone)) errors.phone = 'Invalid phone'
  if (!values.password) errors.password = 'Password required'
  else if (values.password.length < 8) errors.password = 'At least 8 characters'
  if (!values.confirmPassword) errors.confirmPassword = 'Confirm password'
  else if (values.password !== values.confirmPassword) errors.confirmPassword = 'Passwords must match'
  return errors
}

function RegisterForm() {
  const [values, setValues] = useState(initialValues)
  const [errors, setErrors] = useState({})
  const [message, setMessage] = useState('')

  const handleChange = event => {
    setValues({ ...values, [event.target.name]: event.target.value })
    setErrors({ ...errors, [event.target.name]: '' })
    setMessage('')
  }

  const handleSubmit = event => {
    event.preventDefault()
    const nextErrors = validate(values)
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length === 0) {
      setMessage(`${values.role === 'librarian' ? 'Librarian' : 'Member'} registration submitted`)
      setValues(initialValues)
    }
  }

  return (
    <form className="card form" onSubmit={handleSubmit}>
      <h2>Create Account</h2>
      <div className="form__row">
        <label>
          First Name
          <input name="firstName" value={values.firstName} onChange={handleChange} />
          {errors.firstName && <span className="form__error">{errors.firstName}</span>}
        </label>
        <label>
          Last Name
          <input name="lastName" value={values.lastName} onChange={handleChange} />
          {errors.lastName && <span className="form__error">{errors.lastName}</span>}
        </label>
      </div>
      <label>
        Email
        <input name="email" type="email" value={values.email} onChange={handleChange} placeholder="user@domain.com" />
        {errors.email && <span className="form__error">{errors.email}</span>}
      </label>
      <label>
        Phone
        <input name="phone" value={values.phone} onChange={handleChange} placeholder="+905551112233" />
        {errors.phone && <span className="form__error">{errors.phone}</span>}
      </label>
      <label>
        Role
        <select name="role" value={values.role} onChange={handleChange}>
          <option value="member">Member</option>
          <option value="librarian">Librarian</option>
        </select>
      </label>
      <div className="form__row">
        <label>
          Password
          <input name="password" type="password" value={values.password} onChange={handleChange} placeholder="Minimum 8 characters" />
          {errors.password && <span className="form__error">{errors.password}</span>}
        </label>
        <label>
          Confirm Password
          <input name="confirmPassword" type="password" value={values.confirmPassword} onChange={handleChange} />
          {errors.confirmPassword && <span className="form__error">{errors.confirmPassword}</span>}
        </label>
      </div>
      <button type="submit">Register</button>
      {message && <p className="form__success">{message}</p>}
    </form>
  )
}

export default RegisterForm
