function MemberDetail({ member }) {
  if (!member) {
    return (
      <section className="card">
        <p>Member not found</p>
      </section>
    )
  }

  return (
    <section className="card member-detail">
      <header>
        <h2>
          {member.first_name} {member.last_name}
        </h2>
        <div className={`status status--${member.status}`}>{member.status}</div>
      </header>
      <dl>
        <div>
          <dt>Member ID</dt>
          <dd>{member.member_id}</dd>
        </div>
        <div>
          <dt>User ID</dt>
          <dd>{member.user_id}</dd>
        </div>
        <div>
          <dt>Phone</dt>
          <dd>{member.phone_number}</dd>
        </div>
        <div>
          <dt>Date of Birth</dt>
          <dd>{member.date_of_birth}</dd>
        </div>
        <div>
          <dt>Membership Date</dt>
          <dd>{member.membership_date}</dd>
        </div>
        <div>
          <dt>Current Loans</dt>
          <dd>{member.current_loans}</dd>
        </div>
      </dl>
    </section>
  )
}

export default MemberDetail
