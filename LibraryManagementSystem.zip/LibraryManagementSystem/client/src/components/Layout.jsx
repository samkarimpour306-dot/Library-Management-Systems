import { Outlet } from 'react-router-dom'
import NavBar from './NavBar'

function Layout() {
  return (
    <div className="layout">
      <NavBar />
      <main className="layout__content">
        <Outlet />
      </main>
    </div>
  )
}

export default Layout
