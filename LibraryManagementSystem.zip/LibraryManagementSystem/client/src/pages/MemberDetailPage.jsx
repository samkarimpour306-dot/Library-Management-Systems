import { Link, useParams } from 'react-router-dom'
import MemberDetail from '../components/MemberDetail'
import { members } from '../data/members'

function MemberDetailPage() {
  const { memberId } = useParams()
  const member = members.find(item => item.member_id === Number(memberId))

  return (
    <div className="page">
      <Link to="/members" className="link">
        Back to Members
      </Link>
      <MemberDetail member={member} />
    </div>
  )
}

export default MemberDetailPage
