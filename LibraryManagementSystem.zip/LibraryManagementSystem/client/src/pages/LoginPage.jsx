import LoginForm from '../components/LoginForm'

function LoginPage() {
  return (
    <div className="page">
      <LoginForm />
    </div>
  )
}

export default LoginPage
