import MemberList from '../components/MemberList'

function MembersPage() {
  return (
    <div className="page">
      <h1>Members</h1>
      <MemberList />
    </div>
  )
}

export default MembersPage
