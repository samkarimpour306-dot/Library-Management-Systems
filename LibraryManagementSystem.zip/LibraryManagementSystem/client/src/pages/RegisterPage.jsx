import RegisterForm from '../components/RegisterForm'

function RegisterPage() {
  return (
    <div className="page">
      <RegisterForm />
    </div>
  )
}

export default RegisterPage
