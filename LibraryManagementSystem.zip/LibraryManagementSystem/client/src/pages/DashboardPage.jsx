import { Link } from 'react-router-dom'
import { members } from '../data/members'

function DashboardPage() {
  const activeMembers = members.filter(member => member.status === 'active').length
  const delinquentMembers = members.filter(member => member.status === 'delinquent').length

  return (
    <section className="grid">
      <div className="card highlight">
        <h1>Library Management System</h1>
        <p>Monitor member records, manage authentication, and keep catalog data synchronized through the shared API.</p>
        <div className="highlight__actions">
          <Link to="/members" className="button">
            View Members
          </Link>
          <Link to="/login" className="button button--ghost">
            Login
          </Link>
        </div>
      </div>
      <div className="card stats">
        <h2>Members</h2>
        <dl>
          <div>
            <dt>Total</dt>
            <dd>{members.length}</dd>
          </div>
          <div>
            <dt>Active</dt>
            <dd>{activeMembers}</dd>
          </div>
          <div>
            <dt>Delinquent</dt>
            <dd>{delinquentMembers}</dd>
          </div>
        </dl>
      </div>
    </section>
  )
}

export default DashboardPage
