import { Router } from 'express'
import { z } from 'zod'
import { createBook, deleteBook, getBook, listBooks, updateBook } from '../data/booksStore.js'

const router = Router()

const baseSchema = z
  .object({
    isbn: z.string().length(13),
    title: z.string().min(1),
    publisher: z.string().min(1),
    publication_year: z.coerce.number().int().min(1400).max(2100),
    total_copies: z.coerce.number().int().min(0),
    available_copies: z.coerce.number().int().min(0),
    summary: z.string().optional()
  })
  .refine(data => data.available_copies <= data.total_copies, {
    message: 'available_copies cannot exceed total_copies',
    path: ['available_copies']
  })

const createSchema = baseSchema
const updateSchema = baseSchema.omit({ isbn: true })

router.get('/', (req, res) => {
  res.json(listBooks())
})

router.get('/:isbn', (req, res) => {
  const book = getBook(req.params.isbn)
  if (!book) {
    res.status(404).json({ message: 'Book not found' })
    return
  }
  res.json(book)
})

router.post('/', (req, res) => {
  const parsed = createSchema.safeParse(req.body)
  if (!parsed.success) {
    res.status(400).json({ errors: parsed.error.flatten() })
    return
  }
  if (getBook(parsed.data.isbn)) {
    res.status(409).json({ message: 'Book with this ISBN already exists' })
    return
  }
  const created = createBook(parsed.data)
  res.status(201).json(created)
})

router.put('/:isbn', (req, res) => {
  const parsed = updateSchema.safeParse(req.body)
  if (!parsed.success) {
    res.status(400).json({ errors: parsed.error.flatten() })
    return
  }
  const updated = updateBook(req.params.isbn, parsed.data)
  if (!updated) {
    res.status(404).json({ message: 'Book not found' })
    return
  }
  res.json(updated)
})

router.delete('/:isbn', (req, res) => {
  const deleted = deleteBook(req.params.isbn)
  if (!deleted) {
    res.status(404).json({ message: 'Book not found' })
    return
  }
  res.status(204).end()
})

export default router
