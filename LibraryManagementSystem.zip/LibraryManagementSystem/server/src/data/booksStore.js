const now = () => new Date().toISOString()

const books = [
  {
    isbn: '9789753638100',
    title: 'Saatleri Ayarlama Enstitusu',
    publisher: 'Iletisim Yayinlari',
    publication_year: 2015,
    total_copies: 8,
    available_copies: 5,
    summary: 'Modern Turkish classic by Ahmet Hamdi Tanpinar.',
    created_date: now(),
    updated_date: now()
  },
  {
    isbn: '9786050959325',
    title: 'Kurk Mantolu Madonna',
    publisher: 'Yapi Kredi',
    publication_year: 2021,
    total_copies: 12,
    available_copies: 7,
    summary: 'Sabahattin Ali novel about identity and love.',
    created_date: now(),
    updated_date: now()
  }
]

export function listBooks() {
  return books
}

export function getBook(isbn) {
  return books.find(book => book.isbn === isbn)
}

export function createBook(data) {
  const book = { ...data, created_date: now(), updated_date: now() }
  books.push(book)
  return book
}

export function updateBook(isbn, data) {
  const index = books.findIndex(book => book.isbn === isbn)
  if (index === -1) return null
  books[index] = { ...books[index], ...data, updated_date: now() }
  return books[index]
}

export function deleteBook(isbn) {
  const index = books.findIndex(book => book.isbn === isbn)
  if (index === -1) return false
  books.splice(index, 1)
  return true
}
