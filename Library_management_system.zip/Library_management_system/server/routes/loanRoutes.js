const express = require('express');
const router = express.Router();
const loanController = require('../controllers/loanController');

router.post('/lend', loanController.lendBook);
router.post('/return', loanController.returnBook);

module.exports = router;