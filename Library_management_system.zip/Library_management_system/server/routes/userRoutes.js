const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// Sadece üyeleri listeleme rotası
router.get('/', userController.getAllUsers);

module.exports = router;