const express = require('express');
const router = express.Router();
const bookController = require('../controllers/bookController');

router.get('/', bookController.getAllBooks);
router.get('/:isbn', bookController.getBookById);
router.post('/add', bookController.addBook);

module.exports = router;