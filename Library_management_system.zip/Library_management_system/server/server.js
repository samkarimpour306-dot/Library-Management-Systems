const userRoutes = require('./routes/userRoutes');
const express = require('express');
const cors = require('cors');
require('dotenv').config();
const db = require('./config/db');

// Rota dosyalarımızı çağırıyoruz
const authRoutes = require('./routes/authRoutes');
const bookRoutes = require('./routes/bookRoutes');
const reportRoutes = require('./routes/reportRoutes');

// Uygulamayı oluşturuyoruz
const app = express();

// Middleware (Ara Yazılımlar)
app.use(cors());
app.use(express.json());

app.use('/api/users', userRoutes);

// Rotaları Tanımlıyoruz
app.use('/api/auth', authRoutes);
app.use('/api/books', bookRoutes);
app.use('/api/reports', reportRoutes);

// Basit Test Rotası
app.get('/', (req, res) => {
    res.send('Library Management System API Çalışıyor! - Efendim Black');
});

// Veritabanı Test Rotası
app.get('/test-db', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT 1 + 1 AS result');
        res.json({ message: 'Veritabanı bağlantısı başarılı!', result: rows[0].result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Veritabanına bağlanılamadı' });
    }
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Sunucu ${PORT} portunda çalışıyor...`);
});

const loanRoutes = require('./routes/loanRoutes');
app.use('/api/loans', loanRoutes);