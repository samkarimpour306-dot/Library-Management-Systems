const db = require('../config/db');

exports.getOverdueBooks = async (req, res) => {
    try {
        const sql = `
            SELECT l.loan_id, u.email, b.title, l.due_date, DATEDIFF(CURRENT_DATE, l.due_date) as days_overdue
            FROM Loans l
            JOIN Users u ON l.user_id = u.user_id
            JOIN Books b ON l.isbn = b.isbn
            WHERE l.due_date < CURRENT_DATE AND l.status = 'Active'
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};