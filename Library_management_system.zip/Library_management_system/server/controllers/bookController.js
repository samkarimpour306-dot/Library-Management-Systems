const db = require('../config/db');

// Tüm kitapları getir (Search, Filter, Sort dahil)
exports.getAllBooks = async (req, res) => {
    try {
        const { search, genre, sort } = req.query;
        let sql = `SELECT b.* FROM Books b 
                   LEFT JOIN Book_Author ba ON b.isbn = ba.isbn 
                   LEFT JOIN Authors a ON ba.author_id = a.author_id
                   LEFT JOIN Book_Genre bg ON b.isbn = bg.isbn
                   LEFT JOIN Genres g ON bg.genre_id = g.genre_id
                   WHERE 1=1`;
        
        const params = [];

        if (search) {
            sql += ` AND (b.title LIKE ? OR a.first_name LIKE ? OR a.last_name LIKE ?)`;
            params.push(`%${search}%`, `%${search}%`, `%${search}%`);
        }
        if (genre) {
            sql += ` AND g.genre_name = ?`;
            params.push(genre);
        }
        
        sql += ` GROUP BY b.isbn`;

        if (sort === 'newest') sql += ` ORDER BY b.publication_year DESC`;
        else if (sort === 'oldest') sql += ` ORDER BY b.publication_year ASC`;
        else if (sort === 'title_z_a') sql += ` ORDER BY b.title DESC`;
        else sql += ` ORDER BY b.title ASC`;

        const [rows] = await db.query(sql, params);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Kitap Ekleme
exports.addBook = async (req, res) => {
    try {
        const { isbn, title, publisher, publication_year, total_copies } = req.body;
        await db.query(
            "INSERT INTO Books (isbn, title, publisher, publication_year, total_copies, available_copies) VALUES (?, ?, ?, ?, ?, ?)", 
            [isbn, title, publisher, publication_year, total_copies, total_copies]
        );
        res.status(201).json({ message: 'Kitap eklendi' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Detay Getir
exports.getBookById = async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM Books WHERE isbn = ?", [req.params.isbn]);
        if (rows.length === 0) return res.status(404).json({ message: 'Bulunamadı' });
        res.json(rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};