const db = require('../config/db');

// 1. KİTAP ÖDÜNÇ VERME (Lend Book)
exports.lendBook = async (req, res) => {
    const connection = await db.getConnection();
    try {
        await connection.beginTransaction();

        const { email, isbn } = req.body; // Kim alıyor, hangi kitabı alıyor?

        // A. Kullanıcıyı Bul
        const [users] = await connection.query("SELECT user_id FROM Users WHERE email = ?", [email]);
        if (users.length === 0) throw new Error("Kullanıcı bulunamadı!");
        const userId = users[0].user_id;

        // B. Kitabın Stok Durumunu Kontrol Et
        const [books] = await connection.query("SELECT available_copies FROM Books WHERE isbn = ?", [isbn]);
        if (books.length === 0) throw new Error("Kitap bulunamadı!");
        if (books[0].available_copies <= 0) throw new Error("Kitap stokta yok!");

        // C. Ödünç Tablosuna Ekle (Loans)
        // 15 gün sonrası için tarih belirliyoruz
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + 15);

        await connection.query(
            "INSERT INTO Loans (user_id, isbn, loan_date, due_date, status) VALUES (?, ?, CURRENT_DATE, ?, 'Active')",
            [userId, isbn, dueDate]
        );

        // D. Kitap Stok Sayısını 1 Düşür
        await connection.query("UPDATE Books SET available_copies = available_copies - 1 WHERE isbn = ?", [isbn]);

        await connection.commit();
        res.json({ message: 'Kitap başarıyla ödünç verildi.' });

    } catch (error) {
        await connection.rollback();
        res.status(500).json({ message: error.message });
    } finally {
        connection.release();
    }
};

// 2. KİTAP İADE ALMA (Return Book)
exports.returnBook = async (req, res) => {
    const connection = await db.getConnection();
    try {
        await connection.beginTransaction();
        const { loan_id, isbn } = req.body;

        // A. Loans tablosunu güncelle (Status = Returned)
        await connection.query(
            "UPDATE Loans SET return_date = CURRENT_DATE, status = 'Returned' WHERE loan_id = ?", 
            [loan_id]
        );

        // B. Kitap Stok Sayısını 1 Artır
        await connection.query("UPDATE Books SET available_copies = available_copies + 1 WHERE isbn = ?", [isbn]);

        await connection.commit();
        res.json({ message: 'Kitap iade alındı.' });

    } catch (error) {
        await connection.rollback();
        res.status(500).json({ message: 'İade işleminde hata oluştu.' });
    } finally {
        connection.release();
    }
};