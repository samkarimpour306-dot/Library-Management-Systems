const db = require('../config/db');

// Tüm Kullanıcıları Getir
exports.getAllUsers = async (req, res) => {
    try {
        // Users tablosu ile Members tablosunu birleştirip detaylı bilgi çekelim
        const sql = `
            SELECT 
                u.user_id, 
                u.email, 
                u.role, 
                u.created_date,
                m.first_name, 
                m.last_name
            FROM Users u
            LEFT JOIN Members m ON u.user_id = m.user_id
            ORDER BY u.created_date DESC
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};