const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // 1. Kullanıcıyı bul
        const [users] = await db.query('SELECT * FROM Users WHERE email = ?', [email]);
        
        if (users.length === 0) {
            return res.status(404).json({ message: 'Kullanıcı bulunamadı!' });
        }

        const user = users[0];

        // 2. Şifreyi kontrol et (Hash kıyaslama)
        // Not: Şu an veritabanında hashli şifre yoksa manuel olarak "12345" ile kıyaslayamayız.
        // Şimdilik düz metin kontrolü yapalım (Login'i test etmek için), sonra bcrypt'i açarız.
        
        /* const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) return res.status(401).json({ message: 'Şifre hatalı!' });
        */
       
        // GEÇİCİ OLARAK DÜZ KONTROL (Test İçin):
        if (password !== user.password_hash) {
             return res.status(401).json({ message: 'Şifre hatalı!' });
        }

        // 3. Token oluştur (İçine user_id ve role bilgisini gömüyoruz)
        const token = jwt.sign(
            { id: user.user_id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );

        res.json({
            message: 'Giriş Başarılı',
            token,
            user: { id: user.user_id, email: user.email, role: user.role }
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Sunucu hatası' });
    }
};

exports.register = async (req, res) => {
    try {
        const { email, password, first_name, last_name, role } = req.body;

        // 1. Email kontrolü (Zaten var mı?)
        const [existingUser] = await db.query('SELECT user_id FROM Users WHERE email = ?', [email]);
        if (existingUser.length > 0) {
            return res.status(400).json({ message: 'Bu email zaten kayıtlı!' });
        }

        // 2. Kullanıcıyı Users tablosuna ekle
        // (Not: Gerçek projede şifreyi bcrypt ile hashlemeliyiz ama şimdilik düz kaydediyoruz)
        const [userResult] = await db.query(
            "INSERT INTO Users (email, password_hash, role) VALUES (?, ?, ?)",
            [email, password, role || 'Member']
        );
        const newUserId = userResult.insertId;

        // 3. Eğer rolü 'Member' ise, Members tablosuna da detay ekle
        // (Admin veya Librarian için Member tablosuna gerek yok, ama Member için şart)
        if (role === 'Member' || !role) {
            await db.query(
                "INSERT INTO Members (user_id, first_name, last_name, membership_date) VALUES (?, ?, ?, CURRENT_DATE)",
                [newUserId, first_name, last_name]
            );
        }
        // Eğer 'Librarian' veya 'Admin' ise Authors tablosuna eklemeye gerek yok, Users yeterli.

        res.status(201).json({ message: 'Kayıt başarılı!' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Kayıt sırasında hata oluştu.' });
    }
};