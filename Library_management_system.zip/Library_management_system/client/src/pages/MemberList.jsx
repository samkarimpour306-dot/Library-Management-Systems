import React, { useState, useEffect } from 'react';
import api from '../api';

const MemberList = () => {
    const [members, setMembers] = useState([]);

    useEffect(() => {
        const fetchMembers = async () => {
            try {
                // Backend'den üyeleri çekecek (API'sini birazdan ekleriz)
                const res = await api.get('/users'); 
                setMembers(res.data);
            } catch (error) {
                console.error("Üyeler çekilemedi", error);
            }
        };
        fetchMembers();
    }, []);

    return (
        <div style={{ padding: '20px' }}>
            <h2>Üye Listesi (Admin Paneli)</h2>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                    <tr style={{ background: '#f2f2f2', textAlign: 'left' }}>
                        <th style={{ padding: '10px' }}>ID</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Kayıt Tarihi</th>
                    </tr>
                </thead>
                <tbody>
                    {members.map((member) => (
                        <tr key={member.user_id} style={{ borderBottom: '1px solid #ddd' }}>
                            <td style={{ padding: '10px' }}>{member.user_id}</td>
                            <td>{member.email}</td>
                            <td>{member.role}</td>
                            <td>{new Date(member.created_date).toLocaleDateString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default MemberList;