import React, { useState, useEffect } from 'react';
import api from '../api';

const AdminDashboard = () => {
    const [overdues, setOverdues] = useState([]);

    useEffect(() => {
        api.get('/reports/overdue').then(res => setOverdues(res.data));
    }, []);

    return (
        <div style={{ padding: '20px' }}>
            <h1>Admin Paneli</h1>
            <h2>Gecikmiş Kitaplar</h2>
            <ul>
                {overdues.map((item, i) => (
                    <li key={i} style={{ color: 'red' }}>
                        {item.title} - {item.email} ({item.days_overdue} Gün Gecikmiş)
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default AdminDashboard;