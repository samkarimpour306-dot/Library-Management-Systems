import React, { useState, useEffect } from 'react';
import api from '../api';
import { Link } from 'react-router-dom';

const BookList = () => {
    const [books, setBooks] = useState([]);
    const [search, setSearch] = useState("");
    const [sort, setSort] = useState("title");
    const [genre, setGenre] = useState("");

    // Backend'den kitapları çek
    const fetchBooks = async () => {
        try {
            // Backend'de yazdığımız Search/Filter/Sort API'sine istek atıyoruz
            const response = await api.get(`/books?search=${search}&sort=${sort}&genre=${genre}`);
            setBooks(response.data);
        } catch (error) {
            console.error("Hata:", error);
        }
    };

    // Arama veya filtre değişince tekrar çek
    useEffect(() => {
        fetchBooks();
    }, [search, sort, genre]);

    return (
        <div style={{ padding: '20px' }}>
            <h1>Kütüphane Kitapları</h1>

            {/* FİLTRELEME ALANI */}
            <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
                <input 
                    type="text" 
                    placeholder="Kitap Ara..." 
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    style={{ padding: '8px' }}
                />
                
                <select onChange={(e) => setSort(e.target.value)} style={{ padding: '8px' }}>
                    <option value="title">İsim (A-Z)</option>
                    <option value="newest">En Yeni</option>
                    <option value="oldest">En Eski</option>
                </select>

                <select onChange={(e) => setGenre(e.target.value)} style={{ padding: '8px' }}>
                    <option value="">Tüm Türler</option>
                    <option value="Science Fiction">Bilim Kurgu</option>
                    <option value="History">Tarih</option>
                    <option value="Novel">Roman</option>
                </select>
            </div>

            {/* KİTAP KARTLARI */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '20px' }}>
                {books.map((book) => (
                    <div key={book.isbn} style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px' }}>
                        <h3>{book.title}</h3>
                        <p><strong>Yazar:</strong> {book.authors}</p>
                        <p><strong>Tür:</strong> {book.genres}</p>
                        <p>Status: {book.available_copies > 0 ? <span style={{color:'green'}}>Mevcut</span> : <span style={{color:'red'}}>Tükendi</span>}</p>
                        
                        {/* Detay sayfasına gitme linki */}
                        <Link to={`/book/${book.isbn}`}>
                            <button style={{ marginTop: '10px', padding: '5px 10px', cursor: 'pointer' }}>Detayları Gör</button>
                        </Link>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default BookList;