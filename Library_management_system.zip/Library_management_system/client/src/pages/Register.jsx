import React, { useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';

const Register = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        first_name: '',
        last_name: '',
        role: 'Member' // Varsayılan olarak Member
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            // Backend'de henüz register API'si yazmadık ama hazırlık olsun
            // Şimdilik login rotasına değil, oluşturacağımız yeni rotaya istek atacak
            await api.post('/auth/register', formData); 
            alert('Kayıt Başarılı! Giriş yapabilirsiniz.');
            navigate('/login');
        } catch (error) {
            alert('Kayıt başarısız: ' + (error.response?.data?.message || 'Hata'));
        }
    };

    return (
        <div style={{ maxWidth: '400px', margin: '50px auto', padding: '20px', border: '1px solid #ddd' }}>
            <h2>Kayıt Ol</h2>
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <input name="first_name" placeholder="Ad" onChange={handleChange} required />
                <input name="last_name" placeholder="Soyad" onChange={handleChange} required />
                <input name="email" type="email" placeholder="Email" onChange={handleChange} required />
                <input name="password" type="password" placeholder="Şifre" onChange={handleChange} required />
                
                {/* Sadece Admin yeni Admin ekleyebilir, burası normal kayıt için gizlenebilir */}
                <select name="role" onChange={handleChange}>
                    <option value="Member">Öğrenci (Member)</option>
                    <option value="Librarian">Personel (Librarian)</option>
                </select>

                <button type="submit" style={{ padding: '10px', background: 'blue', color: 'white' }}>Kaydol</button>
            </form>
        </div>
    );
};

export default Register;