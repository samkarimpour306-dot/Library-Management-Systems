import React, { useState } from 'react';
import api from '../api';

const LoanBook = () => {
    const [formData, setFormData] = useState({ email: '', isbn: '' });
    const [message, setMessage] = useState('');

    const handleLend = async (e) => {
        e.preventDefault();
        try {
            await api.post('/loans/lend', formData);
            setMessage('✅ İşlem Başarılı! Kitap verildi.');
        } catch (error) {
            setMessage('❌ Hata: ' + (error.response?.data?.message || 'Bilinmeyen hata'));
        }
    };

    return (
        <div style={{ padding: '20px', maxWidth: '400px', margin: 'auto', border: '1px solid #ddd', borderRadius: '10px' }}>
            <h2>📚 Kitap Ödünç Ver (Personel)</h2>
            <form onSubmit={handleLend} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                
                <div>
                    <label>Öğrenci Email:</label>
                    <input 
                        type="email" 
                        placeholder="ogrenci@okul.edu.tr"
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        style={{ width: '100%', padding: '8px' }}
                        required
                    />
                </div>

                <div>
                    <label>Kitap ISBN:</label>
                    <input 
                        type="text" 
                        placeholder="978-..."
                        onChange={(e) => setFormData({...formData, isbn: e.target.value})}
                        style={{ width: '100%', padding: '8px' }}
                        required
                    />
                </div>

                <button type="submit" style={{ background: '#28a745', color: 'white', padding: '10px', border: 'none', cursor: 'pointer' }}>
                    Ödünç Ver
                </button>
            </form>
            
            {message && <p style={{ marginTop: '10px', fontWeight: 'bold' }}>{message}</p>}
        </div>
    );
};

export default LoanBook;