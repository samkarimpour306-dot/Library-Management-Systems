import React, { useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const res = await api.post('/auth/login', { email, password });
            
            // Token'ı tarayıcı hafızasına kaydet
            localStorage.setItem('token', res.data.token);
            localStorage.setItem('user', JSON.stringify(res.data.user)); // Rol bilgisi burada!

            alert('Hoşgeldin ' + res.data.user.role);
            
            // Rolüne göre yönlendir
            if (res.data.user.role === 'Admin') {
                navigate('/admin');
            } else {
                navigate('/');
            }
            
            // Sayfayı yenile ki Navbar güncellensin (Basit yöntem)
            window.location.reload(); 

        } catch (error) {
            alert('Giriş başarısız! Email veya şifre yanlış.');
        }
    };

    return (
        <div style={{ maxWidth: '400px', margin: '50px auto', padding: '20px', border: '1px solid #ddd' }}>
            <h2>Giriş Yap</h2>
            <form onSubmit={handleLogin}>
                <div style={{ marginBottom: '10px' }}>
                    <label>Email:</label>
                    <input 
                        type="email" 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        style={{ width: '100%', padding: '8px' }}
                    />
                </div>
                <div style={{ marginBottom: '10px' }}>
                    <label>Şifre:</label>
                    <input 
                        type="password" 
                        value={password} 
                        onChange={(e) => setPassword(e.target.value)} 
                        style={{ width: '100%', padding: '8px' }}
                    />
                </div>
                <button type="submit" style={{ width: '100%', padding: '10px', background: 'green', color: 'white' }}>Giriş Yap</button>
            </form>
        </div>
    );
};

export default Login;