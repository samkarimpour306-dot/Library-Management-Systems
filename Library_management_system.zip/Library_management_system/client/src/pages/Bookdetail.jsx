import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api';

const BookDetail = () => {
    const { isbn } = useParams(); // URL'den ISBN'i al
    const [book, setBook] = useState(null);

    useEffect(() => {
        const fetchDetail = async () => {
            try {
                const res = await api.get(`/books/${isbn}`);
                setBook(res.data);
            } catch (error) {
                console.error("Detay alınamadı", error);
            }
        };
        fetchDetail();
    }, [isbn]);

    if (!book) return <div>Yükleniyor...</div>;

    return (
        <div style={{ padding: '20px', maxWidth: '600px', margin: 'auto' }}>
            <Link to="/">← Listeye Dön</Link>
            <h1>{book.title}</h1>
            <h3>Yazar: {book.authors}</h3>
            <p><strong>Yayınevi:</strong> {book.publisher} ({book.publication_year})</p>
            <p><strong>Özet:</strong> {book.summary || "Özet bulunmuyor."}</p>
            <p><strong>Stok:</strong> {book.available_copies} / {book.total_copies}</p>
            
            <div style={{ marginTop: '20px' }}>
                {/* Buraya ileride "Ödünç Al" butonu gelecek */}
                <button disabled={book.available_copies === 0} style={{ padding: '10px 20px', background: 'blue', color: 'white' }}>
                    {book.available_copies > 0 ? "Ödünç Al" : "Stokta Yok"}
                </button>
            </div>
        </div>
    );
};

export default BookDetail;