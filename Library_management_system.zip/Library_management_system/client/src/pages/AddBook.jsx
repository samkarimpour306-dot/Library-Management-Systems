import React, { useState } from 'react';
import api from '../api';

const AddBook = () => {
    const [formData, setFormData] = useState({});

    const handleChange = (e) => setFormData({...formData, [e.target.name]: e.target.value});

    const handleSubmit = async (e) => {
        e.preventDefault();
        await api.post('/books/add', formData);
        alert('Eklendi!');
    };

    return (
        <form onSubmit={handleSubmit} style={{ padding: '20px', display:'flex', flexDirection:'column', width:'300px' }}>
            <input name="isbn" placeholder="ISBN" onChange={handleChange} />
            <input name="title" placeholder="Başlık" onChange={handleChange} />
            <input name="publisher" placeholder="Yayınevi" onChange={handleChange} />
            <input name="publication_year" placeholder="Yıl" onChange={handleChange} />
            <input name="total_copies" placeholder="Stok" onChange={handleChange} />
            <button type="submit">Kaydet</button>
        </form>
    );
};

export default AddBook;