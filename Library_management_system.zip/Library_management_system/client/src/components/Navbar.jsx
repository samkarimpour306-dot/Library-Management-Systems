import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Navbar = () => {
    const navigate = useNavigate();
    
    // LocalStorage'dan kullanıcıyı al
    const userString = localStorage.getItem('user');
    const user = userString ? JSON.parse(userString) : null;

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        navigate('/login');
        window.location.reload();
    };

    return (
        <nav style={{ padding: '15px', background: '#333', color: 'white', display: 'flex', gap: '15px' }}>
            <Link to="/" style={{ color: 'white', textDecoration: 'none' }}>Ana Sayfa</Link>
            
            {/* HERKES GÖREMEZ - SADECE GİRİŞ YAPANLAR */}
            {user && (
                <span style={{ color: 'lightgreen' }}>Merhaba, {user.email} ({user.role})</span>
            )}

            {/* SADECE ADMIN VE LIBRARIAN GÖRÜR */}
            {user && (user.role === 'Admin' || user.role === 'Librarian') && (
                <Link to="/add-book" style={{ color: 'orange', textDecoration: 'none' }}>Kitap Ekle</Link>
            )}

            {/* SADECE ADMIN GÖRÜR */}
            {user && user.role === 'Admin' && (
                <Link to="/admin" style={{ color: 'red', textDecoration: 'none', fontWeight: 'bold' }}>YÖNETİM PANELİ</Link>
            )}

            <div style={{ marginLeft: 'auto' }}>
                {user ? (
                    <button onClick={handleLogout} style={{ cursor: 'pointer' }}>Çıkış Yap</button>
                ) : (
                    <Link to="/login" style={{ color: 'white' }}>Giriş Yap</Link>
                )}
            </div>
        </nav>
    );
};

{/* ... Mevcut kodların arasına ekle ... */}

{/* LIBRARIAN ve ADMIN GÖREBİLİR */}
{user && (user.role === 'Admin' || user.role === 'Librarian') && (
    <>
        <Link to="/add-book" style={{ color: 'orange' }}>Kitap Ekle</Link>
        <Link to="/loan-book" style={{ color: '#4ade80' }}>Ödünç Ver</Link> {/* YENİ EKLENDİ */}
    </>
)}

export default Navbar;