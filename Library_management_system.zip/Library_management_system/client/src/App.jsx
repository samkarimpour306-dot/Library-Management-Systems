import { Routes, Route } from 'react-router-dom';
import BookList from './pages/BookList';
import BookDetail from './pages/BookDetail';
import Register from './pages/Register';
import MemberList from './pages/MemberList';

function App() {
  return (
    <div className="App">
      {/* Sayfa Yönlendirmeleri */}
      <Routes>
        <Route path="/" element={<BookList />} />
        <Route path="/book/:isbn" element={<BookDetail />} />
      </Routes>
    </div>
  );
}

export default App;

import Navbar from './components/Navbar';
import Login from './pages/Login';
// ... diğer importlar

function App() {
  return (
    <div className="App">
      <Navbar /> {/* Sayfanın en tepesine ekledik */}
      <Routes>
        <Route path="/register" element={<Register />} />
        <Route path="/members" element={<MemberList />} /> 
        <Route path="/" element={<BookList />} />
        <Route path="/book/:isbn" element={<BookDetail />} />
        <Route path="/login" element={<Login />} />
        <Route path="/add-book" element={<AddBook />} />
        {/* Admin rotasını birazdan yapacağız */}
      </Routes>
    </div>
  );
}

import LoanBook from './pages/LoanBook';
// ...
<Route path="/loan-book" element={<LoanBook />} />

